package net.mcreator.foodexpirydate.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.commands.CommandSourceStack;

import net.mcreator.foodexpirydate.network.FoodExpiryDateModVariables;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.DoubleArgumentType;

public class SetDayCountProcedureProcedure {
	public static void execute(LevelAccessor world, CommandContext<CommandSourceStack> arguments) {
		FoodExpiryDateModVariables.MapVariables.get(world).daysPassed = DoubleArgumentType.getDouble(arguments, "days");
		FoodExpiryDateModVariables.MapVariables.get(world).syncData(world);
	}
}
