package net.mcreator.foodexpirydate.procedures;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.ItemTags;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.foodexpirydate.network.FoodExpiryDateModVariables;
import net.mcreator.foodexpirydate.init.FoodExpiryDateModItems;

import javax.annotation.Nullable;

import java.util.concurrent.atomic.AtomicReference;
import java.util.ArrayList;

@Mod.EventBusSubscriber
public class FoodExpiryDateForInventoryProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.player.level());
		}
	}

	public static void execute(LevelAccessor world) {
		execute(null, world);
	}

	private static void execute(@Nullable Event event, LevelAccessor world) {
		double selectedSlot = 0;
		for (Entity entityiterator : new ArrayList<>(world.players())) {
			selectedSlot = 0;
			{
				AtomicReference<IItemHandler> _iitemhandlerref = new AtomicReference<>();
				entityiterator.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(_iitemhandlerref::set);
				if (_iitemhandlerref.get() != null) {
					for (int _idx = 0; _idx < _iitemhandlerref.get().getSlots(); _idx++) {
						ItemStack itemstackiterator = _iitemhandlerref.get().getStackInSlot(_idx).copy();
						if (itemstackiterator.getOrCreateTag().getBoolean("dried") != true) {
							if (itemstackiterator.getItem().isEdible() || itemstackiterator.is(ItemTags.create(new ResourceLocation(((ForgeRegistries.ITEMS.getKey(Items.MILK_BUCKET).toString())).toLowerCase(java.util.Locale.ENGLISH))))) {
								if (itemstackiterator.getOrCreateTag().getDouble(" creationDate") <= -1) {
									itemstackiterator.getOrCreateTag().putDouble(" creationDate", FoodExpiryDateModVariables.MapVariables.get(world).daysPassed);
								} else if (FoodExpiryDateModVariables.MapVariables.get(world).daysPassed - itemstackiterator.getOrCreateTag().getDouble(" creationDate") > 5) {
									if (itemstackiterator.getItem() == Items.MILK_BUCKET) {
										{
											ItemStack _isc = itemstackiterator;
											final ItemStack _setstack = new ItemStack(FoodExpiryDateModItems.MOLDY_MILK.get());
											final int _sltid = (int) selectedSlot;
											_setstack.setCount(itemstackiterator.getCount());
											_isc.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
												if (capability instanceof IItemHandlerModifiable itemHandlerModifiable) {
													itemHandlerModifiable.setStackInSlot(_sltid, _setstack);
												}
											});
										}
										{
											final int _slotid = (int) selectedSlot;
											final ItemStack _setstack = itemstackiterator;
											_setstack.setCount(itemstackiterator.getCount());
											entityiterator.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
												if (capability instanceof IItemHandlerModifiable _modHandler)
													_modHandler.setStackInSlot(_slotid, _setstack);
											});
										}
									} else {
										{
											ItemStack _isc = itemstackiterator;
											final ItemStack _setstack = new ItemStack(FoodExpiryDateModItems.MOLDY_FOOD.get());
											final int _sltid = (int) selectedSlot;
											_setstack.setCount(itemstackiterator.getCount());
											_isc.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
												if (capability instanceof IItemHandlerModifiable itemHandlerModifiable) {
													itemHandlerModifiable.setStackInSlot(_sltid, _setstack);
												}
											});
										}
										{
											final int _slotid = (int) selectedSlot;
											final ItemStack _setstack = itemstackiterator;
											_setstack.setCount(itemstackiterator.getCount());
											entityiterator.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
												if (capability instanceof IItemHandlerModifiable _modHandler)
													_modHandler.setStackInSlot(_slotid, _setstack);
											});
										}
									}
								}
							}
						}
						selectedSlot = selectedSlot + 1;
					}
				}
			}
		}
	}
}
