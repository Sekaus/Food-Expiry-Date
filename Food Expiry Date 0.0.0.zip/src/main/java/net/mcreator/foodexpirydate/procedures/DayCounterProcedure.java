package net.mcreator.foodexpirydate.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.foodexpirydate.network.FoodExpiryDateModVariables;

import javax.annotation.Nullable;

import java.util.ArrayList;

@Mod.EventBusSubscriber
public class DayCounterProcedure {
	@SubscribeEvent
	public static void onWorldTick(TickEvent.LevelTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.level);
		}
	}

	public static void execute(LevelAccessor world) {
		execute(null, world);
	}

	private static void execute(@Nullable Event event, LevelAccessor world) {
		boolean allPlayerIsSleeping = false;
		double sleepTimer = 0;
		double runningProceduresCalls = 0;
		runningProceduresCalls = runningProceduresCalls + 1;
		allPlayerIsSleeping = false;
		for (Entity entityiterator : new ArrayList<>(world.players())) {
			allPlayerIsSleeping = entityiterator instanceof LivingEntity _livEnt0 && _livEnt0.isSleeping();
		}
		if (allPlayerIsSleeping) {
			sleepTimer = sleepTimer + 1;
			if (sleepTimer == 101) {
				if (allPlayerIsSleeping && !(world instanceof Level _lvl2 && _lvl2.isDay())) {
					FoodExpiryDateModVariables.MapVariables.get(world).daysPassed = FoodExpiryDateModVariables.MapVariables.get(world).daysPassed + 1;
					FoodExpiryDateModVariables.MapVariables.get(world).syncData(world);
				}
			}
		} else {
			sleepTimer = 0;
		}
		if (world.dayTime() == 24000) {
			FoodExpiryDateModVariables.MapVariables.get(world).daysPassed = FoodExpiryDateModVariables.MapVariables.get(world).daysPassed + 1 / (runningProceduresCalls + 1);
			FoodExpiryDateModVariables.MapVariables.get(world).syncData(world);
		} else {
			FoodExpiryDateModVariables.MapVariables.get(world).daysPassed = Math.floor(FoodExpiryDateModVariables.MapVariables.get(world).daysPassed);
			FoodExpiryDateModVariables.MapVariables.get(world).syncData(world);
		}
		runningProceduresCalls = runningProceduresCalls - 1;
	}
}
